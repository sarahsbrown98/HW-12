// JavaScript source code
let x = 100;
let y = 100;
var l = 200;
var m = 200;
var speed = 4;
var speed2 = 2;
var a = 100;
var b = 100;
var clickx = 0;
var clicky = 0;

function setup() {
    createCanvas(400, 400);
    fill(255, 0, 0);
}

function draw() {
    background(220);

    obstacles();
    createPlayer();
    controlCircle();
    createCircle();
    exit();
    youWin();



}

function mouseClicked() {
    fill(190, 90, 111);
    circle(clickx, clicky, 20);
    clickx = mouseX;
    clicky = mouseY;
}

function controlCircle() {
    if (keyIsDown(LEFT_ARROW)) {
        x -= 5;
    }

    if (keyIsDown(RIGHT_ARROW)) {
        x += 5;
    }

    if (keyIsDown(UP_ARROW)) {
        y -= 5;
    }

    if (keyIsDown(DOWN_ARROW)) {
        y += 5;
    }





}

function createPlayer() {
    fill(255, 0, 0);
    ellipse(x, y, 50, 50);
    if (x >= 400) { x = 0; }
    else if (y >= 400) { y = 0; }

}

function obstacles() {
    randomColor = color(random(255), random(255), random(255))
    diameter = random(10, 55)
    fill(randomColor);
    circle(l, m, diameter);
    circle(a, b, diameter);

    l += speed;
    b += speed2;

    if (l >= width) { l = 0; }
    else if (m >= height) { m = 0; }

    if (a >= width) { x = 0; }
    else if (b >= height) { b = 0; }

}

function createCircle() {
    fill(190, 90, 111);
    circle(clickx, clicky, 20);
}

function exit() {
    fill(0);
    rect(300, 0, 80, 50);
    fill(255);
    textSize(30);
    text("Exit", 300, 30)
}

function youWin() {
    if (x > 300 && y <= 50) {
        text("You Won!", 150, 50);
    }

}
